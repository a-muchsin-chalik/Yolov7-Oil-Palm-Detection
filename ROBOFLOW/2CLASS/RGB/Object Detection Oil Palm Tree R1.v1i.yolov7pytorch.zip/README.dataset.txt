# Object Detection Oil Palm Tree R1 > 2023-03-02 9:46am
https://universe.roboflow.com/esqbs/object-detection-oil-palm-tree-r1

Provided by a Roboflow user
License: CC BY 4.0

