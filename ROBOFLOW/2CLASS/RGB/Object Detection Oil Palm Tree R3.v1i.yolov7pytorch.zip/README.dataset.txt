# Object Detection Oil Palm Tree R3 > 2023-04-08 1:20am
https://universe.roboflow.com/esqbs/object-detection-oil-palm-tree-r3

Provided by a Roboflow user
License: CC BY 4.0

