# Object Detection Oil Palm Tree R2 > 2023-04-10 6:25am
https://universe.roboflow.com/esqbs/object-detection-oil-palm-tree-r2

Provided by a Roboflow user
License: CC BY 4.0

